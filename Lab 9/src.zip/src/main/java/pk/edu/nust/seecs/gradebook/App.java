
package pk.edu.nust.seecs.gradebook;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pk.edu.nust.seecs.gradebook.bo.TeacherBo;

import javax.swing.*;
import java.util.ArrayList;


public class App extends JFrame implements Runnable {


    public App() {

        ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("ApplicationContext.xml");
        TeacherBo teacherHandler = (TeacherBo) context.getBean("teacherHandler");

        teacherHandler.addTeacher("Fahad Satti");

    }

    ArrayList<Integer> courseIds = new ArrayList<>();
    @Override
    public void run() {
        this.setVisible(true);
    }
    public static void main(String[] args) {
        App admin = new App();
        Thread t = new Thread(admin);
        t.start();
    }
}
