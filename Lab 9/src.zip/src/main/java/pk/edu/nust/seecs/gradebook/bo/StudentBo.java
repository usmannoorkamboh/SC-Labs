package pk.edu.nust.seecs.gradebook.bo;

import pk.edu.nust.seecs.gradebook.dao.StudentDao;
import pk.edu.nust.seecs.gradebook.entity.Student;

import java.util.ArrayList;
import java.util.List;


public class StudentBo {
    StudentDao sDao;

    public List<Student> getMyStudent() {
        return myStudent;
    }

    public void setMyStudent(List<Student> myStudent) {
        this.myStudent = myStudent;
    }

    List<Student> myStudent;

    public StudentBo()
    {
        sDao = new StudentDao();
        myStudent = new ArrayList<>();
    }

}
