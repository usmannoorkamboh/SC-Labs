package pk.edu.nust.seecs.gradebook.bo;

import pk.edu.nust.seecs.gradebook.dao.TeacherDao;
import pk.edu.nust.seecs.gradebook.entity.Course;
import pk.edu.nust.seecs.gradebook.entity.Teacher;

public class TeacherBo {
    public TeacherDao getDao() {
        return dao;
    }

    public void setDao(TeacherDao dao) {
        this.dao = dao;
    }

    private TeacherDao dao;

    public TeacherBo() {
    }

    public void addTeacher(String name) {
        dao.addTeacher(new Teacher(name));
    }

    public Teacher getTeacherbyName(String name) {
        return dao.getTeacherByName(name);
    }

    public void updateTeacher(Teacher t) {
        dao.updateTeacher(t);
    }

    public void addCourse(String tname, Course c) {
        Teacher t = getTeacherbyName(tname);
        t.addCourse(c);
        dao.updateTeacher(t);
    }
}
