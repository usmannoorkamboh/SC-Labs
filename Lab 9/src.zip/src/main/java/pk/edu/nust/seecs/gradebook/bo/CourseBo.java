package pk.edu.nust.seecs.gradebook.bo;

import pk.edu.nust.seecs.gradebook.dao.CourseDao;
import pk.edu.nust.seecs.gradebook.entity.Course;
import pk.edu.nust.seecs.gradebook.entity.Teacher;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class CourseBo {
    CourseDao cDao;

    public CourseDao getcDao() {
        return cDao;
    }

    public void setCourseDao(CourseDao cDao) {
        this.cDao = cDao;
    }

    public List<Course> getMyCourses() {
        return myCourses;
    }

    public void setMyCourses(List<Course> myCourses) {
        this.myCourses = myCourses;
    }

    List<Course> myCourses;
    public CourseBo()
    {
        cDao = new CourseDao();
        myCourses = new ArrayList<>();
    }

    public void addCourse(Course c)
    {
        myCourses.add(c);
    }

    public void printCourses()
    {
        for(int a =0;a <myCourses.size(); a++)
        {
            System.out.println(myCourses.get(a).getClasstitle());
            System.out.println(myCourses.get(a).getTeacher().getName());
        }
    }
    public void commitCourses()
    {
        for(int a =0;a <myCourses.size(); a++)
        {
            cDao.addCourse(myCourses.get(a));
        }
    }

    public void commitCourse(String classtitle, Date starttime, Date endtime, int creditHours)
    {
        cDao.addCourse(new Course(classtitle, starttime, endtime, creditHours));
    }
    public void updateCourse(Course c)
    {
        cDao.updateCourse(c);
    }

    public Course getCourseByName(String name)
    {
        return cDao.getCourseByName(name);
    }

    public void addTeacher(String courseName, Teacher t)
    {
        Course c = getCourseByName(courseName);
        c.setTeacher(t);
        updateCourse(c);
    }
}
